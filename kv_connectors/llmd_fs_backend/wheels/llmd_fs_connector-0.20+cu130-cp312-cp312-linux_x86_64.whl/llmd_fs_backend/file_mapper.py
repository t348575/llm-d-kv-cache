# Copyright 2025 The llm-d Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import hashlib
import json
import os

from vllm.config import VllmConfig
from vllm.v1.kv_cache_interface import KVCacheConfig
from vllm.v1.kv_offload.abstract import (
    OffloadKey,
    get_offload_block_hash,
    get_offload_group_idx,
)

_BASE_PATH_HASH_LEN = 12
_CONFIG_FILENAME = "config.json"


class FileMapper:
    """
    FileMapper maps KV blocks (given by their hash) to file names.
    """

    def __init__(
        self,
        root_dir: str,
        model_name: str,
        gpu_block_size: int,
        gpu_blocks_per_file: int,
        tp_size: int,
        pp_size: int,
        pcp_size: int,
        rank: int,
        dtype: str,
        kv_cache_groups: list[dict] | None = None,
        inference_engine: str = "vllm",
    ):
        """
        Initialize the file mapper for a specific worker.

        Side-effect free: only computes self.base_path. Call `write_run_config`
        to persist run metadata. All fields (incl. kv_cache_groups and
        inference_engine) are hashed into the base path, so any change
        produces a fresh folder.
        """
        self.fields: dict = {
            "model_name": model_name,
            "gpu_block_size": gpu_block_size,
            "gpu_blocks_per_file": gpu_blocks_per_file,
            "tp_size": tp_size,
            "pp_size": pp_size,
            "pcp_size": pcp_size,
            "rank": rank,
            "dtype": str(dtype),
            "kv_cache_groups": kv_cache_groups or [],
            "inference_engine": inference_engine,
        }
        self.base_path: str = self._compute_base_path(root_dir, self.fields)

    @classmethod
    def from_vllm_config(
        cls,
        root_dir: str,
        vllm_config: VllmConfig,
        kv_cache_config: KVCacheConfig,
        gpu_block_size: int,
        gpu_blocks_per_file: int,
    ) -> "FileMapper":
        """Build a FileMapper from a vllm VllmConfig + KVCacheConfig."""
        parallel_config = vllm_config.parallel_config
        dtype = str(vllm_config.cache_config.cache_dtype).replace("torch.", "")
        kv_cache_groups = [
            {
                "num_layers": len(group.layer_names),
                "block_size": group.kv_cache_spec.block_size,
                "spec_type": type(group.kv_cache_spec).__name__,
            }
            for group in kv_cache_config.kv_cache_groups
        ]
        return cls(
            root_dir=root_dir,
            model_name=vllm_config.model_config.model,
            gpu_block_size=gpu_block_size,
            gpu_blocks_per_file=gpu_blocks_per_file,
            tp_size=parallel_config.tensor_parallel_size,
            pp_size=parallel_config.pipeline_parallel_size,
            pcp_size=parallel_config.prefill_context_parallel_size,
            rank=parallel_config.rank,
            dtype=dtype,
            kv_cache_groups=kv_cache_groups,
        )

    def get_file_name(self, key: OffloadKey) -> str:
        """Map an OffloadKey to <base>/<hhh>/<hh>_g<group_idx>/<hash>.bin."""
        hash_hex = get_offload_block_hash(key).hex()
        group_idx = get_offload_group_idx(key)
        subfolder1, subfolder2 = hash_hex[:3], hash_hex[3:5]
        return f"{self.base_path}/{subfolder1}/{subfolder2}_g{group_idx}/{hash_hex}.bin"

    def write_run_config(self) -> None:
        """Write self.fields as JSON to <base_path>/config.json (no-op if it exists)."""
        run_config = dict(self.fields)
        os.makedirs(self.base_path, exist_ok=True)
        target = os.path.join(self.base_path, _CONFIG_FILENAME)
        if os.path.exists(target):
            return
        with open(target, "w") as f:
            json.dump(run_config, f, indent=2, sort_keys=True)

    @staticmethod
    def _compute_base_path(root_dir: str, fields: dict) -> str:
        """
        Layout: <root_dir>/<safe_model_name>_<sha256-prefix>/.
        safe_model_name replaces '/' with '_' so HuggingFace IDs don't nest.
        """
        canonical = json.dumps(fields, sort_keys=True, separators=(",", ":"))
        digest = hashlib.sha256(canonical.encode("utf-8")).hexdigest()[
            :_BASE_PATH_HASH_LEN
        ]
        safe_model_name = fields["model_name"].replace("/", "_")
        return f"{root_dir}/{safe_model_name}_{digest}"
